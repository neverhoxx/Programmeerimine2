using MediatR;
using Microsoft.AspNetCore.Mvc;
using KooliProjekt.Application.Features.Students;

namespace KooliProjekt.WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CourcesController : ControllerBase
    {
        private readonly IMediator _mediator;

        public CourcesController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult> List()
        {
            var result = await _mediator.Send(new ListCourcesQuery());
            return Ok(result);
        }
    }
}