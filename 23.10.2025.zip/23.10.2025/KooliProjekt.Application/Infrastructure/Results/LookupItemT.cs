﻿namespace KooliProjekt.Application.Infrastructure.Results
{
    public class LookupItem<T>
    {
        public T Value { get; set; }
        public string Text { get; set; }
    }
}