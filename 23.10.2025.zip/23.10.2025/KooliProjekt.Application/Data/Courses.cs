namespace KooliProjekt.Application.Data
{
    public class Course
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Credits { get; set; }

        public ICollection<StudentCourse> StudentCourses { get; set; }
    }
}