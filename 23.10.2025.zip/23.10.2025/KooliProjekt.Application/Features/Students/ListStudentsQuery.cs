using MediatR;
using Microsoft.EntityFrameworkCore;
using KooliProjekt.Application.Data;

namespace KooliProjekt.Application.Features.Students
{
	public class ListStudentsQuery : IRequest<List<StudentDto>> { }

	public class ListStudentsHandler : IRequestHandler<ListStudentsQuery, List<StudentDto>>
	{
		private readonly ApplicationDbContext _context;

		public ListStudentsHandler(ApplicationDbContext context)
		{
			_context = context;
		}

		public async Task<List<StudentDto>> Handle(ListStudentsQuery request, CancellationToken cancellationToken)
		{
			var students = await _context.Students
				.Select(s => new StudentDto
				{
					Id = s.Id,
					FirstName = s.FirstName,
					LastName = s.LastName
				})
				.ToListAsync(cancellationToken);

			return students;
		}
	}

	public class StudentDto
	{
		public int Id { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
	}
}