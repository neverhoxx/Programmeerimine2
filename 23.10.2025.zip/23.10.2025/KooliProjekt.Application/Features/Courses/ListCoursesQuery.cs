using MediatR;
using Microsoft.EntityFrameworkCore;
using KooliProjekt.Application.Data;

namespace KooliProjekt.Application.Features.Cources
{
    public class ListCourcesQuery : IRequest<List<CourseDto>> { }

    public class ListCourcesHandler : IRequestHandler<ListStudentsQuery, List<CourseDto>>
    {
        private readonly ApplicationDbContext _context;

        public ListCourcesHandler(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<CourseDto>> Handle(ListCoursesQuery request, CancellationToken cancellationToken)
        {
            var students = await _context.Courses
                .Select(s => new CourseDto
                {
                    Id = s.Id,
                    FirstName = s.FirstName,
                    LastName = s.LastName
                })
                .ToListAsync(cancellationToken);

            return courses;
        }
    }

    public class CourseDto
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}